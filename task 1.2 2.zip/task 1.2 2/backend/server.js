import http from 'http';
import coBody from 'co-body';
import pg from 'pg';

const { Pool } = pg;

const PORT = 3002;
const pool = new Pool({
  user: 'postgres',
  host: '127.0.0.1',
  database: 'myapp',
  password: 'asko228228',
  port: 5432
});




 function send(res, data) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/users') {
  const result = await pool.query('SELECT * FROM users');
  send(res, result.rows);
  return;
}

if (req.method === 'POST' && req.url === '/register') {
  const newUser = await coBody.json(req);
  await pool.query(
  'INSERT INTO users (name, email, password) VALUES ($1, $2, $3)',
  [newUser.name, newUser.email, newUser.password]
);
  send(res, { message: 'User registered' });
  return;
}

if (req.method === 'PUT' && req.url === '/users') {
  const user = await coBody.json(req);

  await pool.query(
    'UPDATE users SET name = $1 WHERE id = $2',
    [user.name, user.id]
  );

  send(res, { message: 'User updated' });
  return;
}
 



if (req.method === 'DELETE' && req.url === '/users') {
  const user = await coBody.json(req);

  await pool.query(
    'DELETE FROM users WHERE id = $1',
    [user.id]
  );

  send(res, { message: 'User deleted' });
  return;
}


if (req.method === 'POST' && req.url === '/login') {
  const loginData = await coBody.json(req);

  const result = await pool.query(
    'SELECT * FROM users WHERE email = $1 AND password = $2',
    [loginData.email, loginData.password]
  );

  const userFound = result.rows.length > 0;

  if (userFound) {
    send(res, { message: 'Login successful' });
  } else {
    send(res, { message: 'Wrong email or password' });
  }

  return;
}

send(res, { message: 'Not found' });
});


server.listen(PORT, () => {
  console.log('Server is running on port:', PORT);
});
