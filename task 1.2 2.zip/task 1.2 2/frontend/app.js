const API = 'http://localhost:3002';

const modal = document.querySelector('[data-modal]');

function openModal() {
  modal.classList.add('open');
}

function closeModal() {
  modal.classList.remove('open');
}

function registerUser(event) {
  event.preventDefault();

  fetch(API + '/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      password: document.getElementById('password').value,
      joined: new Date().toLocaleDateString()
    })
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      alert(data.message);
      document.querySelector('[data-registration]').reset();
    });
}

function loginUser(event) {
  event.preventDefault();

  fetch(API + '/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      email: document.getElementById('login-email').value,
      password: document.getElementById('login-password').value
    })
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      alert(data.message);

      if (data.message === 'Login successful') {
        closeModal();
      }
    });
}

function showMembers() {
  const tableBody = document.querySelector('[data-members]');
  const counter = document.querySelector('[data-member-count]');

  if (!tableBody) {
    return;
  }

  fetch(API + '/users')
    .then(function (response) {
      return response.json();
    })
    .then(function (users) {
      tableBody.replaceChildren();

      users.forEach(function (user, index) {
        const row = document.createElement('tr');
        row.innerHTML =
          '<td>' + (index + 1) + '</td>' +
          '<td>' + user.name + '</td>' +
          '<td>' + user.email + '</td>' +
          '<td>' + user.joined + '</td>';
        tableBody.appendChild(row);
      });

      if (counter) {
        counter.textContent = users.length + ' registered readers';
      }
    });
}

document.querySelectorAll('[data-open-login]').forEach(function (button) {
  button.addEventListener('click', openModal);
});

document.querySelectorAll('[data-close-modal]').forEach(function (button) {
  button.addEventListener('click', closeModal);
});

const registrationForm = document.querySelector('[data-registration]');
const loginForm = document.querySelector('[data-login]');

if (registrationForm) {
  registrationForm.addEventListener('submit', registerUser);
}

if (loginForm) {
  loginForm.addEventListener('submit', loginUser);
}

showMembers();